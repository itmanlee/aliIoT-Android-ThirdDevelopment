package com.aliIoT.demo.model;

/**
 *
 */
public class ParameterVerifyBean {
    public String md5VerifyString;
    public String randomString;
    public String randomIndexString;
    public int index;
}
